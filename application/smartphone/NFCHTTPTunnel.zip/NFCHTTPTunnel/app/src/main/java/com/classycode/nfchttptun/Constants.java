package com.classycode.nfchttptun;

/**
 * @author Alex Suzuki, Classy Code GmbH, 2017
 */
class Constants {

    static final String LOG_TAG = "NFCHTTPTUN";
}
